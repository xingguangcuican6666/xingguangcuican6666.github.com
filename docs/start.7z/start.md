# home
This is a Minecraft mod pack build and public web. <br>

如果你想下载服务器整合包，java整合包 [点这里](https://xingguangcuican6666.github.io/#/?id=Java版整合包 "github") ,基岩版[点这里](https://xingguangcuican6666.github.io/#/?id=基岩版 "github")<br>




# Java版整合包 

服务器IP: 

~~~
play.simpfun.cn:20008
~~~
Java版整合包下载地址
---
1.16.5 [fabric辅助包](https://github.com/xingguangcuican6666/xingguangcuican6666.github.com/releases/tag/1.16.5 "github") <br>

Java [x64 all](https://mirrors.tuna.tsinghua.edu.cn/Adoptium/17/jdk/x64/windows/ "Java") <br>

基岩版 <br>
---

服务器IP:
~~~
play.simpfun.cn 
~~~
端口:
~~~
20008
~~~
基岩版下载地址
---
非beta [点击此处下载](https://bbk.endyun.ltd/main "基岩版") <br>
打开后选择原版下载即可
